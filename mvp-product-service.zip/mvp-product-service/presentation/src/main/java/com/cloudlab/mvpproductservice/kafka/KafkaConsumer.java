//package com.cloudlab.mvpproductservice.kafka;
//
//import com.cloudlab.mvpproductservice.data.event.OrderEvent;
//import com.cloudlab.mvpproductservice.exceptions.BusinessException;
//import org.springframework.kafka.support.Acknowledgment;
//
//public interface KafkaConsumer {
//     void updateStock(OrderEvent event, Acknowledgment ack) throws BusinessException;
//}
