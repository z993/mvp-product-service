//package com.cloudlab.mvpproductservice.kafka;
//
//import com.cloudlab.mvpproductservice.data.event.OrderEvent;
//import com.cloudlab.mvpproductservice.exceptions.BusinessException;
//import com.cloudlab.mvpproductservice.service.ProductService;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.kafka.support.Acknowledgment;
//import org.springframework.stereotype.Service;
//
//import javax.transaction.Transactional;
//
//@Slf4j
//@Service
//public class KafkaConsumerImpl implements KafkaConsumer {
//
//    ProductService productService;
//
//    @Autowired
//    public KafkaConsumerImpl(ProductService productService) {
//        this.productService = productService;
//    }
//
//    @Override
//    @KafkaListener(topics = "${spring.kafka.topic.order-event}")
//    public void updateStock(OrderEvent event, Acknowledgment ack) throws BusinessException {
//        log.info("Consume kafka message event type : "
//                + event.getEventType()
//                + ", timestamp : "
//                + event.getTimestamp());
//
//        log.info("Consume kafka message message : " + event.toJson());
//        productService.updateStock(event.getMessageId(), event);
//        ack.acknowledge();
//    }
//}
