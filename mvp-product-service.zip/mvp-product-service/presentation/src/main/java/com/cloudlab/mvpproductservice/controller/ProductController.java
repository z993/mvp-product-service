package com.cloudlab.mvpproductservice.controller;

import com.cloudlab.mvpproductservice.data.dto.ProductDto;
import com.cloudlab.mvpproductservice.service.ProductService;
import com.cloudlab.mvpproductservice.data.entity.ProductEntity;
import com.cloudlab.mvpproductservice.vo.ResponseProduct;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;

import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/product-service")
public class ProductController {

    private Environment env;
    ProductService productService;

    @Autowired
    public ProductController(Environment env, ProductService productService) {
        this.env = env;
        this.productService = productService;
    }

    @GetMapping("/products")
    public ResponseEntity<List<ResponseProduct>> getUsers() {
        Iterable<ProductEntity> userList = productService.getAllCatalog();

        List<ResponseProduct> result = new ArrayList<>();

        userList.forEach(v -> {
            result.add(new ModelMapper().map(v, ResponseProduct.class));
        });

        return ResponseEntity.status(HttpStatus.OK).body(result);
    }

    @GetMapping(value = "/products/{productId}")
    public ResponseEntity<ResponseProduct> getProductById(@PathVariable String productId) {
        log.info("product service is invoked");
        ProductEntity productEntity = productService.getProductById(productId);
        if (productEntity == null) {
            log.info("Invalid product id " + productId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        ResponseProduct responseProduct = new ModelMapper().map(productEntity, ResponseProduct.class);
        return ResponseEntity.status(HttpStatus.OK).body(responseProduct);
    }

    @PutMapping(value = "/products/{productId}")
    public ResponseEntity<ResponseProduct> updateProductQty(@PathVariable String productId, @RequestParam int qty) {
        ProductDto productDto = productService.updateStock(productId, qty);
        ResponseProduct responseProduct = new ModelMapper().map(productDto, ResponseProduct.class);
        return ResponseEntity.status(HttpStatus.OK).body(responseProduct);
    }


    //JPA 조회용 API
    @GetMapping(value = "/products/1/{name}")
    public ResponseEntity<List<ResponseProduct>> getProductsByName(@PathVariable String name) {
//        ModelMapper modelMapper = new ModelMapper();
        Iterable<ProductEntity> productList = productService.getCatalogByName(name);
//        Iterable<ProductEntity> productList = productService.
        List<ResponseProduct> result = new ArrayList<>();
        productList.forEach(v -> {
            result.add(new ModelMapper().map(v, ResponseProduct.class));
        });
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }
    @GetMapping(value = "/products/2/{name}/{qty}")
    public ResponseEntity<List<ResponseProduct>> getProductsByNameAndQty(@PathVariable String name, @PathVariable int qty) {
        Iterable<ProductEntity> productList = productService.getCatalogByNameAndQty(name, qty);
//        Iterable<ProductEntity> productList = productService.selectProductsByNameAndQty(name, qty);
        List<ResponseProduct> result = new ArrayList<>();
        productList.forEach(v -> {
            result.add(new ModelMapper().map(v, ResponseProduct.class));
        });
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }
    @GetMapping(value = "/products/3/{name}/{qty}")
    public ResponseEntity<List<ResponseProduct>> getProductsByNameAndQtyAsc(@PathVariable String name, @PathVariable int qty) {
        Iterable<ProductEntity> productList = productService.getCatalogByNameAndQtyAsc(name, qty);
        List<ResponseProduct> result = new ArrayList<>();
        productList.forEach(v -> {
            result.add(new ModelMapper().map(v, ResponseProduct.class));
        });
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }
    @GetMapping(value = "/products/4/{name}/{qty}/{price}")
    public ResponseEntity<List<ResponseProduct>> getProductsByNameAndQtyAndPriceAsc(@PathVariable String name, @PathVariable int qty, @PathVariable int price) {
        Iterable<ProductEntity> productList = productService.getCatalogByNameAndQtyAndPriceAsc(name, qty, price);
        List<ResponseProduct> result = new ArrayList<>();
        productList.forEach(v -> {
            result.add(new ModelMapper().map(v, ResponseProduct.class));
        });
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }


}