package com.cloudlab.mvpproductservice.service;

import com.cloudlab.mvpproductservice.data.dto.ProductDto;
import com.cloudlab.mvpproductservice.data.entity.OrderStatus;
import com.cloudlab.mvpproductservice.data.entity.ProcessMessageEntity;
import com.cloudlab.mvpproductservice.data.entity.ProductEntity;
import com.cloudlab.mvpproductservice.data.event.OrderCanceled;
import com.cloudlab.mvpproductservice.data.event.OrderCreated;
import com.cloudlab.mvpproductservice.data.event.OrderEvent;
import com.cloudlab.mvpproductservice.data.repository.ProcessMessageRepository;
import com.cloudlab.mvpproductservice.data.repository.ProductRepository;
import com.cloudlab.mvpproductservice.exceptions.BusinessException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.HashMap;
import java.util.Map;

@Data
@Slf4j
@Service
public class ProductServiceImpl implements ProductService {
    ProductRepository productRepository;
    ProcessMessageRepository processMessageRepository;

    private static final String ORDER_CREATED = "OrderCreated";
    private static final String ORDER_CANCELED = "OrderCanceled";

    @Autowired
    public ProductServiceImpl(ProductRepository productRepository,
                              ProcessMessageRepository processMessageRepository) {
        this.productRepository = productRepository;
        this.processMessageRepository = processMessageRepository;
    }

    @Override
    public Iterable<ProductEntity> getAllCatalog() {
        return productRepository.findAll();
    }

    @Override
    public ProductEntity getProductById(String productId) {
        return productRepository.findByProductId(productId);
    }

    @Override
    public ProductDto updateStock(String productId, int qty) {
        ProductEntity productEntity = productRepository.findByProductId(productId);

        log.info("Current stock of " + productEntity.getProductId() + " is " + productEntity.getStock() + " and it will be decreased by " + qty);
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        productEntity.setStock(productEntity.getStock() - qty);
        productRepository.save(productEntity);
        ProductDto returnProductDto = mapper.map(productEntity, ProductDto.class);
        return returnProductDto;
    }

    @Transactional
    @Override
    public void updateStock(String msgId, OrderEvent event) throws BusinessException {
        if (!isValidationCheck(msgId)) {
            log.error("invalid check");
            throw new RuntimeException();
        }

        saveProcessMessage(msgId, event);
        updateProductStock(event);
    }

    private void updateProductStock(OrderEvent event) throws BusinessException {
        ProductEntity productEntity = productRepository.findByProductId(event.getProductId());

        if (productEntity != null) {
            int orderType = (int) event.getOrderType();
            if (ORDER_CREATED.equals(event.getEventType())) {
                productEntity.setStock(productEntity.getStock() - event.getQty());
                log.info("Decrease stocks based on order");
            } else if (ORDER_CANCELED.equals(event.getEventType())) {
                productEntity.setStock(productEntity.getStock() + event.getQty());
                log.info("Rollback stocks due to compensation logic");
            }
            productRepository.save(productEntity);
        } else {
            throw new BusinessException();
        }
    }

    private void saveProcessMessage(String msgId, OrderEvent event) {
        ProcessMessageEntity processMessageEntity = new ProcessMessageEntity();

        processMessageEntity.setMessageId(msgId);
        processMessageEntity.setProductId(event.getProductId());
        processMessageEntity.setStock(event.getQty());

        processMessageRepository.save(processMessageEntity);
    }

    private boolean isValidationCheck(String msgId) {
        if (processMessageRepository.findByMessageId(msgId) != null) {
            return false;
        }
        return true;
    }


    //JPA 조회용 API
    @Override
    public Iterable<ProductEntity> getCatalogByName(String name) {
//        return productRepository.findProductsByProductNameLike("%"+name+"%");
        return productRepository.selectProductsByName("%"+name+"%");
    }
    @Override
    public Iterable<ProductEntity> getCatalogByNameAndQty(String name, int qty){
//        return productRepository.findProductsByProductNameLikeAndStockGreaterThan("%"+name+"%", qty);
        return productRepository.selectProductsByNameAndQty("%"+name+"%", qty);
    }
    @Override
    public Iterable<ProductEntity> getCatalogByNameAndQtyAsc(String name, int qty){
//        return productRepository.findProductsByProductNameLikeAndStockGreaterThanOrderByProductNameAsc("%"+name+"%", qty);
        return productRepository.selectProductsByNameAndQtyAsc("%"+name+"%", qty);
    }
    @Override
    public Iterable<ProductEntity> getCatalogByNameAndQtyAndPriceAsc(String name, int qty, int price){
//        return productRepository.findProductsByProductNameLikeAndStockGreaterThanAndUnitPriceLessThanEqualOrderByProductNameAsc("%"+name+"%", qty, price);
        return productRepository.selectProductsByNameANdQtyAndPriceAsc("%"+name+"%", qty, price);
    }

}
