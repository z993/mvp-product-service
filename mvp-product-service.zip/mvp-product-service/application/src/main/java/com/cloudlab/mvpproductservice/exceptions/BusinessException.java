package com.cloudlab.mvpproductservice.exceptions;

public class BusinessException extends Throwable {
}
