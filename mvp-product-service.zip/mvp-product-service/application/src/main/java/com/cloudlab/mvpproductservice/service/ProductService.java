package com.cloudlab.mvpproductservice.service;

import com.cloudlab.mvpproductservice.data.dto.ProductDto;
import com.cloudlab.mvpproductservice.data.entity.ProductEntity;
//import com.cloudlab.mvpproductservice.data.event.OrderEvent;
import com.cloudlab.mvpproductservice.exceptions.BusinessException;
import org.springframework.stereotype.Service;

public interface ProductService {
    Iterable<ProductEntity> getAllCatalog();
    ProductEntity getProductById(String productId);
    ProductDto updateStock(String productId, int qty);
//    void updateStock(String msgId, OrderEvent event) throws BusinessException;

    //JPA 조회용 API
    Iterable<ProductEntity> getCatalogByName(String name);
    Iterable<ProductEntity> getCatalogByNameAndQty(String name, int qty);
    Iterable<ProductEntity> getCatalogByNameAndQtyAsc(String name, int qty);
    Iterable<ProductEntity> getCatalogByNameAndQtyAndPriceAsc(String name, int qty, int price);
}
