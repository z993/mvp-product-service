//package com.cloudlab.mvpproductservice.kafka;
//
//import com.cloudlab.mvpproductservice.data.event.AbstractEvent;
//import com.cloudlab.mvpproductservice.data.event.OrderEvent;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.apache.kafka.common.serialization.StringDeserializer;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.kafka.annotation.EnableKafka;
//import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
//import org.springframework.kafka.core.ConsumerFactory;
//import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.listener.*;
//import org.springframework.kafka.support.Acknowledgment;
//import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
//import org.springframework.kafka.support.serializer.JsonDeserializer;
//import org.springframework.retry.backoff.*;
//import org.springframework.retry.policy.SimpleRetryPolicy;
//import org.springframework.retry.support.RetryTemplate;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Slf4j
//@EnableKafka
//@Configuration
//public class KafkaConsumerConfig {
//    @Value(value = "${spring.kafka.consumer.group-id}")
//    private String consumerGroupId;
//
//    @Value("${spring.kafka.bootstrap-servers}")
//    private String bootstrapServers;
//
//    private KafkaTemplate<String, Object> kafkaTemplate;
//
//    @Bean
//    public ConsumerFactory<String, OrderEvent> consumerFactory() {
//        Map<String, Object> properties = new HashMap<>();
//        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
//        properties.put(ConsumerConfig.GROUP_ID_CONFIG, consumerGroupId);
//        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
//        properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
//
//        return new DefaultKafkaConsumerFactory<>(properties,
//                new StringDeserializer(),
//                new ErrorHandlingDeserializer<>(
//                        new JsonDeserializer<>(OrderEvent.class, false)));
//    }
//
//    @Bean
//    public ConcurrentKafkaListenerContainerFactory<String, OrderEvent> kafkaListenerContainerFactory(
//            KafkaTemplate<String, AbstractEvent> kafkaTemplate) {
//        ConcurrentKafkaListenerContainerFactory<String, OrderEvent> factory = new ConcurrentKafkaListenerContainerFactory<>();
//        factory.setConsumerFactory(consumerFactory());
//        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
//        factory.setConcurrency(2);
//        factory.setRetryTemplate(retryTemplate());
//        factory.setRecoveryCallback(context -> {
//            log.info("consumer recovery callback is invoked -" + context.toString());
//            Acknowledgment ack = (Acknowledgment) context.getAttribute("acknowledgment");
//            ConsumerRecord<String, AbstractEvent> record = (ConsumerRecord)
//                    context.getAttribute("record");
//            if (record != null) {
//                String topic = record.topic() + "-DLT";
//                OrderEvent event = (OrderEvent) record.value();
//                log.info("topic - " + topic + " / event - " + event);
//
//                try {
//                    kafkaTemplate.send(topic, event);
//                    log.info("Unhandled message sent to dead letter queue, topic - " + topic +
//                            " / event - " + event);
//                    if (ack != null) {
//                        ack.acknowledge();
//                        log.info("commit for original message since it is sent to dead letter message");
//                    }
//                } catch (Exception e) {
//                    log.error("Exception : ", e);
//
//                }
//            }
//
//            return null;
//        });
////        factory.setErrorHandler(new SeekToCurrentErrorHandler(
////                new DeadLetterPublishingRecoverer(template,
////                        new BiFunction<ConsumerRecord<?, ?>, Exception, TopicPartition>() {
////                            @Override
////                            public TopicPartition apply(ConsumerRecord<?, ?> record, Exception ex) {
////                                return new TopicPartition("order-event-DLT", 0);
////                            }
////                        }),
////                new ExponentialBackOffWithMaxRetries(3)));
//
//        return factory;
//    }
//
//    @Bean
//    public RetryTemplate retryTemplate() {
//        RetryTemplate retryTemplate = new RetryTemplate();
//        retryTemplate.setBackOffPolicy(getBackoffPolicy());
//        retryTemplate.setRetryPolicy(getRetryPolicy());
//        return retryTemplate;
//    }
//
//    private ExponentialBackOffPolicy getBackoffPolicy() {
//        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
//        backOffPolicy.setInitialInterval(1000);
//        backOffPolicy.setMaxInterval(30000);
//        backOffPolicy.setMultiplier(5);
//        return backOffPolicy;
//    }
//
//    private SimpleRetryPolicy getRetryPolicy() {
//        SimpleRetryPolicy simpleRetryPolicy = new SimpleRetryPolicy();
//        simpleRetryPolicy.setMaxAttempts(3);
//        return simpleRetryPolicy;
//    }
//}
