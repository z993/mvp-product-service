//package com.cloudlab.mvpproductservice.jpa;
//
//import com.cloudlab.mvpproductservice.data.entity.ProcessMessageEntity;
//import com.cloudlab.mvpproductservice.data.entity.ProductEntity;
//import com.cloudlab.mvpproductservice.data.repository.ProcessMessageRepository;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface ProcessMessageJpaRepository extends ProcessMessageRepository, CrudRepository<ProcessMessageEntity, Long> {
//    @Override
//    ProcessMessageEntity findByMessageId(String messageId);
//
//    @Override
//    ProcessMessageEntity save(ProcessMessageEntity processMessageEntity);
//}
