package com.cloudlab.mvpproductservice.jpa;

import com.cloudlab.mvpproductservice.data.entity.ProductEntity;
import com.cloudlab.mvpproductservice.data.repository.ProductCustomRepository;
import com.cloudlab.mvpproductservice.data.repository.ProductRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductJpaRepository extends ProductRepository, ProductCustomRepository, CrudRepository<ProductEntity, Long> {
    @Override
    ProductEntity findByProductId(String productId);

    @Override
    Iterable<ProductEntity> findAll();

    @Override
    ProductEntity save(ProductEntity productEntity);


    //JPA 조회용 API
    @Override
    Iterable<ProductEntity> findProductsByProductNameLike(String name);
    @Override
    Iterable<ProductEntity> findProductsByProductNameLikeAndStockGreaterThan(String name, int qty);
    @Override
    Iterable<ProductEntity> findProductsByProductNameLikeAndStockGreaterThanOrderByProductNameAsc(String name, int qty);
    @Override
    Iterable<ProductEntity> findProductsByProductNameLikeAndStockGreaterThanAndUnitPriceLessThanEqualOrderByProductNameAsc(String name, int qty, int price);
}
