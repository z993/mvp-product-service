//package com.cloudlab.mvpproductservice.data.repository;
//
//import com.cloudlab.mvpproductservice.data.entity.ProcessMessageEntity;
//
//public interface ProcessMessageRepository {
//    ProcessMessageEntity findByMessageId(String messageId);
//
//    ProcessMessageEntity save(ProcessMessageEntity processMessageEntity);
//}
