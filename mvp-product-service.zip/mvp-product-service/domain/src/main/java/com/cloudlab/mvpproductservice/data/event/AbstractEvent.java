package com.cloudlab.mvpproductservice.data.event;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

@Slf4j
public class AbstractEvent {
    private String messageId;

    private String eventType;
    private String timestamp;

    public AbstractEvent() {
        this.setMessageId(UUID.randomUUID().toString());
        this.setEventType(this.getClass().getSimpleName());
        this.setTimestamp(new SimpleDateFormat("YYYYMMddHHmmss").format(new Date()));
    }

    public String toJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        String json = null;
        try {
            json = objectMapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("JSON format exception", e);
        }
        return json;
    }


    public String getEventType() {
        return this.eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getMessageId() {
        return this.messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getTimestamp() {
        return this.timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
