//package com.cloudlab.mvpproductservice.data.entity;
//
//public enum OrderStatus {
//
//    CREATED(0),
//    PROCESSING(10),
//    UPDATED(20),
//    DELETED(30),
//    CANCELED(40),
//    CONFIRMED(100);
//
//    int orderStatus;
//
//    OrderStatus(int orderStatus) {
//        this.orderStatus = orderStatus;
//    }
//
//}
