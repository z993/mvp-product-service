//package com.cloudlab.mvpproductservice.data.event;
//
//import com.cloudlab.mvpproductservice.data.entity.OrderStatus;
//import lombok.Data;
//import lombok.EqualsAndHashCode;
//
//@Data
//@EqualsAndHashCode(callSuper = false)
//public class OrderEvent extends AbstractEvent {
//    private String productId;
//    private Integer qty;
//    private Integer unitPrice;
//    private Integer totalPrice;
//    private Integer orderType; // 0:Create, 1:Update, 2: Delete
//    private Integer diffQty;
//
//    private String orderId;
//    private String userId;
//
//    private OrderStatus orderStatus;
//}
