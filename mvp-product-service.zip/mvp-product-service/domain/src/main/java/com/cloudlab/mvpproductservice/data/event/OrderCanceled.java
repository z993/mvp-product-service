//package com.cloudlab.mvpproductservice.data.event;
//
//import lombok.Data;
//import lombok.EqualsAndHashCode;
//
//@Data
//@EqualsAndHashCode(callSuper = false)
//public class OrderCanceled extends OrderEvent {
//}
