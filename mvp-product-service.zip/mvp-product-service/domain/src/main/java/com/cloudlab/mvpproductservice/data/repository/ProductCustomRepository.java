package com.cloudlab.mvpproductservice.data.repository;

import com.cloudlab.mvpproductservice.data.entity.ProductEntity;

public interface ProductCustomRepository {
    Iterable<ProductEntity> selectProductsByName(String name);
    Iterable<ProductEntity> selectProductsByNameAndQty(String name, int qty);
    Iterable<ProductEntity> selectProductsByNameAndQtyAsc(String name, int qty);
    Iterable<ProductEntity> selectProductsByNameANdQtyAndPriceAsc(String name, int qty, int price);
}
