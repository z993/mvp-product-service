package com.cloudlab.mvpproductservice.data.repository;


import com.cloudlab.mvpproductservice.data.entity.ProductEntity;
import com.cloudlab.mvpproductservice.data.entity.QProductEntity;
import com.querydsl.jpa.impl.JPAQueryFactory;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class ProductCustomRepositoryImpl implements ProductCustomRepository {

    @PersistenceContext private EntityManager em;

    @Override
    public Iterable<ProductEntity> selectProductsByName(String name) {
        JPAQueryFactory queryFactory = new JPAQueryFactory(em);
        QProductEntity product = new QProductEntity("tm");
        Iterable<ProductEntity> result = queryFactory.selectFrom(product)
                .where(product.productName.contains(name))
                .fetch();
        return result;
    }

    @Override
    public Iterable<ProductEntity> selectProductsByNameAndQty(String name, int qty) {
        return null;
    }

    @Override
    public Iterable<ProductEntity> selectProductsByNameAndQtyAsc(String name, int qty) {
        return null;
    }

    @Override
    public Iterable<ProductEntity> selectProductsByNameANdQtyAndPriceAsc(String name, int qty, int price) {
        return null;
    }
}
