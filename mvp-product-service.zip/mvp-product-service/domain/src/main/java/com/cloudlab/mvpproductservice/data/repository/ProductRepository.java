package com.cloudlab.mvpproductservice.data.repository;

import com.cloudlab.mvpproductservice.data.entity.ProductEntity;

public interface ProductRepository extends ProductCustomRepository{
    ProductEntity findByProductId(String productId);
    Iterable<ProductEntity> findAll();
    ProductEntity save(ProductEntity productEntity);


    //JPA 조회용 API
    Iterable<ProductEntity> findProductsByProductNameLike(String name);
    Iterable<ProductEntity> findProductsByProductNameLikeAndStockGreaterThan(String name, int qty);
    Iterable<ProductEntity> findProductsByProductNameLikeAndStockGreaterThanOrderByProductNameAsc(String name, int qty);
    Iterable<ProductEntity> findProductsByProductNameLikeAndStockGreaterThanAndUnitPriceLessThanEqualOrderByProductNameAsc(String name, int qty, int price);
}
